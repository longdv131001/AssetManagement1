package com.nashtech.rookie.assetmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
