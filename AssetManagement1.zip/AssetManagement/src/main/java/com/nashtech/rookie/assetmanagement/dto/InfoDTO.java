package com.nashtech.rookie.assetmanagement.dto;

public class InfoDTO {
	
	private String status;
	private String dataSource;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

}
