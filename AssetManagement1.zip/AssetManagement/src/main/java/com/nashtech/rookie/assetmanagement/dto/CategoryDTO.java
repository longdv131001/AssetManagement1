package com.nashtech.rookie.assetmanagement.dto;

import lombok.Data;

@Data
public class CategoryDTO {
	private Long id;
	private String categoryName;
	private String categoryCode;
}
